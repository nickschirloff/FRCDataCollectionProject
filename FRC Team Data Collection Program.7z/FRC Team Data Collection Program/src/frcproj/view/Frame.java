package frcproj.view;

import java.awt.Canvas;
import java.awt.Graphics;

import javax.swing.JFrame;

public class Frame extends JFrame {
	
	Canvas canvas = new Canvas();

	public Frame() {
		super("Data Projection");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1000, 750);
		
		
		setVisible(true);
	}//End of constructor
	
	public void paintComponent(Graphics g) {
		
		
	}
	
	
	
	
	
}//End of class
