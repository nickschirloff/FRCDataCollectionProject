package frcproj.model;
import java.util.HashMap;
import java.util.List;

public class TeamList {

	private HashMap<Integer, List<String>> teamMap = new HashMap<>();
	
	public TeamList() {
		
		
		
		
	}//End of constructor
	
	
	public void addMatch(int matchNum, List<String> data) {
		teamMap.put(matchNum, data);
	}//End of putMatch
	
	
	public HashMap<Integer, List<String>> getList(){
		return teamMap;
	}
	
}//End of class
