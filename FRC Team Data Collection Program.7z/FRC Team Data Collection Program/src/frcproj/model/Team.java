package frcproj.model;

public class Team {
	
	private int number;
	private String name;

	public Team(int number, String name) {
		
		
		
		
		
	}//End of constructor
	
	
}//End of Team
