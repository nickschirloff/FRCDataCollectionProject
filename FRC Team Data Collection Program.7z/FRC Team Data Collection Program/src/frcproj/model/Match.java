package frcproj.model;

import java.util.List;

public class Match {

	private List<String> matchData;
	
	
	
	
	public Match() {

		
		
	}//End of constructor
	
	
	
	
	
}//End of Match
