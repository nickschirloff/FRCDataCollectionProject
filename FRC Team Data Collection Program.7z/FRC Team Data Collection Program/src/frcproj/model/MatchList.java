package frcproj.model;

import java.util.HashMap;
import java.util.List;

public class MatchList {

	private HashMap<Integer, List<Team>> matchMap = new HashMap<>();
	
	
	
	
}//End of MatchList
