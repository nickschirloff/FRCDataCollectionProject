package frcproj.main;

import frcproj.view.Frame;

public class FRCTeamDataProj {

	public static void main(String[] args) {
		new Frame();
	}

}
